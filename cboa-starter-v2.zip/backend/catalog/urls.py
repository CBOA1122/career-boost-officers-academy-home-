
from django.urls import path
from .views import CourseListCreateView, CourseEnrollView

urlpatterns = [
    path('courses', CourseListCreateView.as_view(), name='courses'),
    path('courses/<slug:slug>/enroll', CourseEnrollView.as_view(), name='course-enroll'),
]
