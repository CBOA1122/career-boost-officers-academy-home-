
from rest_framework import generics, permissions, status
from rest_framework.views import APIView
from rest_framework.response import Response
from django.shortcuts import get_object_or_404
from .models import Course, Enrollment
from .serializers import CourseSerializer

class CourseListCreateView(generics.ListCreateAPIView):
    queryset = Course.objects.all().order_by("-id")
    serializer_class = CourseSerializer
    def get_permissions(self):
        if self.request.method == "POST":
            return [permissions.IsAdminUser()]
        return [permissions.AllowAny()]

class CourseEnrollView(APIView):
    permission_classes = [permissions.IsAuthenticated]
    def post(self, request, slug):
        course = get_object_or_404(Course, slug=slug)
        if not course.is_free:
            return Response({"detail":"Course is paid. Purchase required."}, status=402)
        Enrollment.objects.get_or_create(user=request.user, course=course)
        return Response({"detail":"Enrolled"})
