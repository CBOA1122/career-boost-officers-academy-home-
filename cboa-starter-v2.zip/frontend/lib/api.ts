
export const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

export function getToken() {
  if (typeof window === 'undefined') return null;
  return localStorage.getItem('access');
}
export function setTokens(access: string, refresh: string) {
  localStorage.setItem('access', access);
  localStorage.setItem('refresh', refresh);
}
export async function apiGet(path: string) {
  const res = await fetch(`${API_URL}${path}`, {
    headers: { 'Authorization': `Bearer ${getToken() || ''}` }
  });
  return res.json();
}
export async function apiPost(path: string, body: any, authorized=true) {
  const res = await fetch(`${API_URL}${path}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...(authorized ? { 'Authorization': `Bearer ${getToken() || ''}` } : {})
    },
    body: JSON.stringify(body)
  });
  return res.json();
}
