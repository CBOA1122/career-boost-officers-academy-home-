
import './globals.css'
import React from 'react'

export const metadata = { title: 'Career Boost Academy', description: 'Starter v2' }

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-gray-50 text-gray-900">
        <div className="max-w-5xl mx-auto p-6">
          <header className="mb-6 flex items-center justify-between">
            <h1 className="text-2xl font-semibold">Career Boost Academy</h1>
            <nav className="space-x-4">
              <a className="underline" href="/">Home</a>
              <a className="underline" href="/health">Health</a>
              <a className="underline" href="/courses">Courses</a>
              <a className="underline" href="/login">Login</a>
              <a className="underline" href="/register">Register</a>
            </nav>
          </header>
          <main>{children}</main>
        </div>
      </body>
    </html>
  )
}
