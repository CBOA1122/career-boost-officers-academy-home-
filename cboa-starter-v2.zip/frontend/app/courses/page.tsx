
'use client'
import React from 'react'
import { apiGet, apiPost } from '@/lib/api'

type Course = { id:number; title:string; slug:string; description:string; is_free:boolean; price:string }

export default function CoursesPage() {
  const [courses, setCourses] = React.useState<Course[]>([])
  const [msg, setMsg] = React.useState<string>('')

  React.useEffect(() => {
    apiGet('/api/courses').then(setCourses)
  }, [])

  async function enroll(slug: string) {
    const res = await apiPost(`/api/courses/${slug}/enroll`, {}, true)
    setMsg(res.detail || JSON.stringify(res))
  }

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold">Courses</h2>
      {msg && <p className="p-2 border rounded bg-green-50">{msg}</p>}
      <ul className="grid sm:grid-cols-2 gap-4">
        {courses.map(c => (
          <li key={c.id} className="border p-4 rounded bg-white">
            <h3 className="font-medium">{c.title}</h3>
            <p className="text-sm text-gray-600">{c.description}</p>
            <p className="text-sm mt-1">{c.is_free ? 'Free' : `Paid: ${c.price}`}</p>
            {c.is_free && <button onClick={()=>enroll(c.slug)} className="mt-2 px-3 py-1 rounded bg-black text-white">Enroll (Free)</button>}
          </li>
        ))}
      </ul>
    </div>
  )
}
