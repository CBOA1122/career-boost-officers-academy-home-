
'use client'
import React from 'react'
import { API_URL } from '@/lib/api'
import { useRouter } from 'next/navigation'

export default function RegisterPage() {
  const r = useRouter()
  const [form, setForm] = React.useState({ username:'', email:'', password:'', first_name:'', last_name:'' })
  const [error, setError] = React.useState<string|undefined>()
  function set<K extends keyof typeof form>(k: K, v: string){ setForm({ ...form, [k]: v }) }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError(undefined)
    const res = await fetch(`${API_URL}/api/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form)
    })
    if (!res.ok) { const data = await res.json(); setError(JSON.stringify(data)); return }
    r.push('/login')
  }

  return (
    <div className="max-w-sm mx-auto space-y-4">
      <h2 className="text-xl font-semibold">Create Account</h2>
      <form onSubmit={onSubmit} className="space-y-3">
        <input className="w-full border p-2 rounded" placeholder="Username" value={form.username} onChange={e=>set('username', e.target.value)} />
        <input className="w-full border p-2 rounded" placeholder="Email" value={form.email} onChange={e=>set('email', e.target.value)} />
        <input className="w-full border p-2 rounded" placeholder="First name" value={form.first_name} onChange={e=>set('first_name', e.target.value)} />
        <input className="w-full border p-2 rounded" placeholder="Last name" value={form.last_name} onChange={e=>set('last_name', e.target.value)} />
        <input className="w-full border p-2 rounded" placeholder="Password" type="password" value={form.password} onChange={e=>set('password', e.target.value)} />
        <button className="px-4 py-2 rounded bg-black text-white">Register</button>
      </form>
      {error && <p className="text-red-600 break-words">{error}</p>}
    </div>
  )
}
