
export default function Page() {
  return (
    <div className="space-y-4">
      <h2 className="text-xl font-medium">Welcome</h2>
      <p>This is Sprint 1: Auth + Courses + Enrollment (Free).</p>
      <ul className="list-disc pl-6">
        <li>Register/Login to get JWT tokens</li>
        <li>View Courses and enroll into Free ones</li>
        <li>API base at <code>/api</code>, health at <code>/healthz</code></li>
      </ul>
    </div>
  )
}
