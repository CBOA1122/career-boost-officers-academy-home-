
'use client'
import React from 'react'
import { API_URL } from '@/lib/api'

export default function HealthPage() {
  const [status, setStatus] = React.useState<string>('checking...')
  React.useEffect(() => {
    fetch(`${API_URL}/healthz`).then(r=>r.json()).then(d=>setStatus(d.status)).catch(()=>setStatus('error'))
  }, [])
  return (
    <div className="space-y-2">
      <h2 className="text-xl font-semibold">API Health</h2>
      <p>API URL: <code>{API_URL}</code></p>
      <p>Status: <span className="font-semibold">{status}</span></p>
    </div>
  )
}
