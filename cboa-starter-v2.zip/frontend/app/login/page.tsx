
'use client'
import React from 'react'
import { API_URL, setTokens } from '@/lib/api'
import { useRouter } from 'next/navigation'

export default function LoginPage() {
  const r = useRouter()
  const [username, setUsername] = React.useState('')
  const [password, setPassword] = React.useState('')
  const [error, setError] = React.useState<string|undefined>()

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError(undefined)
    const res = await fetch(`${API_URL}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    })
    if (!res.ok) { setError('Invalid credentials'); return }
    const data = await res.json()
    setTokens(data.access, data.refresh)
    r.push('/courses')
  }

  return (
    <div className="max-w-sm mx-auto space-y-4">
      <h2 className="text-xl font-semibold">Login</h2>
      <form onSubmit={onSubmit} className="space-y-3">
        <input className="w-full border p-2 rounded" placeholder="Username" value={username} onChange={e=>setUsername(e.target.value)} />
        <input className="w-full border p-2 rounded" placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
        <button className="px-4 py-2 rounded bg-black text-white">Login</button>
      </form>
      {error && <p className="text-red-600">{error}</p>}
      <p className="text-sm">No account? <a className="underline" href="/register">Register</a></p>
    </div>
  )
}
